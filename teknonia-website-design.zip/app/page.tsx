import { TeknoniaWebsite } from "@/components/teknonia-website"

export default function Home() {
  return <TeknoniaWebsite />
}
